﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalkulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        long a = 0;
        long b = 0;
        string znak = "";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 1;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 1;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 2;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 2;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 3;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 3;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 4;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 4;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 5;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 5;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 6;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 6;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 7;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 7;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 8;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 8;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 9;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 9;
                textDisplay.Text = b.ToString();
            }

        }
        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a * 10 + 0;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b * 10 + 0;
                textDisplay.Text = b.ToString();
            }

        }

        private void btnDivide_Click(object sender, RoutedEventArgs e)
        {
            znak = "/";
            textDisplay.Text = "/";
        }

        private void btnTimes_Click(object sender, RoutedEventArgs e)
        {
            znak = "X";
            textDisplay.Text = "X";
        }

        private void btnSubstract_Click(object sender, RoutedEventArgs e)
        {
            znak = "-";
            textDisplay.Text = "-";
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            znak = "+";
            textDisplay.Text = "+";
        }

        private void btnEquals_Click(object sender, RoutedEventArgs e)
        {
            switch (znak)
            {
                case "+":
                    textDisplay.Text = (a + b).ToString();
                    break;
                case "-":
                    textDisplay.Text = (a - b).ToString();
                    break;
                case "/":
                    textDisplay.Text = (a / b).ToString();
                    break;
                case "X":
                    textDisplay.Text = (a * b).ToString();
                    break;
            }
        }

        private void btnCE_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = 0;
            }
            else
            {
                b = 0;
            }
            textDisplay.Text = "0";
        }

        private void btnC_Click(object sender, RoutedEventArgs e)
        {
            a = 0;
            b = 0;
            znak = "";
            textDisplay.Text = "0";
        }

        private void btnBackspace_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a / 10;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b / 10;
                textDisplay.Text = b.ToString();
            }
        }

        private void btnNoP_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a *= -1;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b *=-1;
                textDisplay.Text = b.ToString();
            }
        }
    }
        
    }
