﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalkulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
         double a = 0;
        double b = 0;
        string znak = "";
        bool comma_a = false;
        bool comma_b = false;
        byte comma_a_count = 1;
        byte comma_b_count = 1;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a==false)
                {
                    a = a * 10 + 1;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a+(1/(Math.Pow(10,comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }
                
            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 1;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (1 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 2;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (2 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 2;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (2 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 3;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (3 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 3;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (3 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 4;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (4 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 4;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (4 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 5;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (5 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 5;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (5 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 6;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (6 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 6;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (6 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 7;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (7 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 7;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (7 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 8;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (8 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 8;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (8 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 9;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (9 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text = a.ToString();
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 9;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (9 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text = b.ToString();
                    comma_b_count++;
                }
            }

        }
        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                if (comma_a == false)
                {
                    a = a * 10 + 0;
                    textDisplay.Text = a.ToString();
                }
                else
                {
                    a = a + (0 / (Math.Pow(10, comma_a_count)));
                    textDisplay.Text += "0";
                    comma_a_count++;
                }

            }
            else
            {
                if (comma_b == false)
                {
                    b = b * 10 + 0;
                    textDisplay.Text = b.ToString();
                }
                else
                {
                    b = b + (0 / (Math.Pow(10, comma_b_count)));
                    textDisplay.Text += "0";
                    comma_b_count++;
                }
            }

        }

        private void btnDivide_Click(object sender, RoutedEventArgs e)
        {
            znak = "/";
            textDisplay.Text = "/";
        }

        private void btnTimes_Click(object sender, RoutedEventArgs e)
        {
            znak = "X";
            textDisplay.Text = "X";
        }

        private void btnSubstract_Click(object sender, RoutedEventArgs e)
        {
            znak = "-";
            textDisplay.Text = "-";
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            znak = "+";
            textDisplay.Text = "+";
        }

        private void btnEquals_Click(object sender, RoutedEventArgs e)
        {
            switch (znak)
            {
                case "+":
                    textDisplay.Text = (a + b).ToString();
                    break;
                case "-":
                    textDisplay.Text = (a - b).ToString();
                    break;
                case "/":
                    textDisplay.Text = (a / b).ToString();
                    break;
                case "X":
                    textDisplay.Text = (a * b).ToString();
                    break;
            }
        }

        private void btnCE_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = 0;
            }
            else
            {
                b = 0;
            }
            textDisplay.Text = "0";
        }

        private void btnC_Click(object sender, RoutedEventArgs e)
        {
            a = 0;
            b = 0;
            znak = "";
            textDisplay.Text = "0";
             comma_a = false;
             comma_b = false;
             comma_a_count = 1;
             comma_b_count = 1;
        }

        private void btnBackspace_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a = a / 10;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b = b / 10;
                textDisplay.Text = b.ToString();
            }
        }

        private void btnNoP_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                a *= -1;
                textDisplay.Text = a.ToString();
            }
            else
            {
                b *=-1;
                textDisplay.Text = b.ToString();
            }
        }

        private void btnComma_Click(object sender, RoutedEventArgs e)
        {
            if (znak == "")
            {
                textDisplay.Text += ",";
                comma_a = true;
            }
            else
            {
                textDisplay.Text += ",";
                comma_b = true;
            }
            
        }
    }
        
    }
