﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Documents;

namespace MiniTC
{
    class Directory 
    {
        public int NumDirectories;
        public int NumFiles;
        private string path = "" ;
        public string Path
        {
            get { return path; }
            set {
                
                path = value;
                NumDirectories = GetDirectories().Count;
                NumFiles = GetFiles().Count;
            }
        }
        public List<string> GetFiles()
        {
            if (path != null)
            {
                int l = path.Length;
            
            var t = new List<string>(System.IO.Directory.EnumerateFiles(Path));


            for (int i = 0; i < t.Count; i++)
            { 
               t[i] = t[i].Substring(l);
            }

            return t;
            }
            return new List<string>();
        }

        public List<string> GetDirectories()
        {
            if (path != null)
            {
                int l = path.Length;

                var t = new List<string>(System.IO.Directory.EnumerateDirectories(Path));

                for (int i = 0; i < t.Count; i++)
                {
                    t[i] = t[i].Substring(l);
                }
                if (l > 3)
                {
                    t.Insert(0, "..");
                }
                return t;
            }
            return new List<string>();
        }

        public void ChangeDirectory(string dir)
        {
            if (dir == "..")
            {
                
                path = path.Substring(0, path.Length - 1);
                int index = path.LastIndexOf("\\");
                if (index > 0)
                    path = path.Substring(0, index+1);
            }
            else
            {
                path += dir + "\\";
            }
            NumDirectories = GetDirectories().Count;
            NumFiles = GetFiles().Count;
        }
        public void CopyHere(string file)
        {
            int index = file.LastIndexOf("\\");
            string filename = file.Substring(index);
            File.Copy(file,path+filename,true);
        }

    }
}
