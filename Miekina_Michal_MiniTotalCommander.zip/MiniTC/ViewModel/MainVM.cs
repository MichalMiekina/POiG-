﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Microsoft.Win32;

namespace MiniTC.ViewModel
{
    using Base;    //add cd and copy command!!!
    internal class MainVM : VMBase
    {
        private Directory LDir = new Directory();
        private Directory RDir = new Directory();

        public PanelVM _left;
        public PanelVM Left
        {
            get
            {
                return _left;
            }
            set
            {
                _left = value;
                onPropertyChanged(nameof(Left));
            }
        }
        public PanelVM _right;
        public PanelVM Right
        {
            get
            {
                return _right;
            }
            set
            {
                _right = value;
                onPropertyChanged(nameof(Right));
            }
        }

        public MainVM()
        {
            Left = new PanelVM(LDir);
            Right = new PanelVM(RDir);
        }

        public ICommand _copy;

        public ICommand Copy
        {

            get
            {
                if (_copy == null)
                {
                    _copy = new RelayCommand(
                        arg => 
                        {   //execute
                            string name = Left.Content[Left.Selected];
                            Right.CP(Left.Path + name);
                            Right.Selected = Right.Content.IndexOf(name);
                            onPropertyChanged(nameof(Right));
                        },  //can execute
                            arg => (Left.Selected > LDir.NumDirectories-1)
                        );
                }
                return _copy;
            }
        }
    }



    }
