﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Microsoft.Win32;


namespace MiniTC.ViewModel
{
    using Base;
    class PanelVM:VMBase
    {
        public void CP(string path)
        {
            Dir.CopyHere(path);
            onPropertyChanged(nameof(Content));
        }




        public ICommand _CD = null;

        public ICommand CD
        {

            get
            {
                if (_CD == null)
                {
                    _CD = new RelayCommand(
                        arg =>
                        { //execute

                            Dir.ChangeDirectory(Dir.GetDirectories()[Selected]);
                            onPropertyChanged(nameof(Path));
                            onPropertyChanged(nameof(Content));

                        }, //can execute
                            arg => (Selected < Dir.NumDirectories)
                        );
                }
                return _CD;
            }
        }

        public ObservableCollection<string> Drives
        {
            get
            {
                return new ObservableCollection<string>(System.IO.Directory.GetLogicalDrives());
            }
        }

        public Directory _Dir = null;

        public Directory Dir
        {
            get
            {
                return _Dir;
            }
            set
            {
                _Dir = value;
                onPropertyChanged(nameof(Dir));
            }

        }

        public int _selected = -1;

        public int Selected
        {
            get
            {
                return _selected;
            }
            set
            {
                _selected = value;
                onPropertyChanged(nameof(Selected));
            }
        }

        public string Path
        {
            get
            {
                return _Dir.Path;
            }
            set
            {
                _Dir.Path = value;
                onPropertyChanged(nameof(Path));
                onPropertyChanged(nameof(Content));
            }
        }

        public ObservableCollection<string> Content
        {
            get
            {
                var t = new List<string>(_Dir.GetDirectories());
                for (int i = 0; i < t.Count; i++)
                {
                    t[i] = "<D>" + t[i];
                }

                t.AddRange(_Dir.GetFiles());
                return new ObservableCollection<string>(t);
            }
        }

        public PanelVM(Directory dir)
        {
            _Dir = dir;
        }

    }
}
